package com.smarteinc.assignment.booking;

public class UserDefineException extends Exception{

	
	
	UserDefineException(String ex)
	{
		super(ex);
	}
}
