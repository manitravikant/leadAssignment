package com.smarteinc.assignment.booking;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Objects;
import java.util.Properties;
import java.util.function.BiPredicate;

import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

public class BookingApp {

static ArrayList<Ticket> busTicketList=null; 
static ArrayList<Ticket> carTicketList=null; 
	
public int bookingProcess(Ticket x) {
	if(x.getType() == 1) {
		validateAllFieldsPresent(x);
		bookBusTicket(x);
		sendTicketBookedMail(x);
	} else if(x.getType() == 2){
		validateAllFieldsPresent(x);
		bookCarTicket(x);
		sendTicketBookedMail(x);
	} else if (x.getType() != 1 && x.getType() != 2) {
		throw new IllegalArgumentException("Only type 1 and 2 tickets are supported");
	}
	
	//method should return the type of ticket booked
	return x.getType();
}

BiPredicate check= (busTicketListdata,x)->{
		
							Iterator<Ticket> iter =  ((ArrayList<Ticket>) busTicketListdata).iterator(); 
								
								while(iter.hasNext())
								{
									Ticket obj=iter.next();
									if((obj.getPassenger().getEmail().equals(((Ticket) x).getPassenger().getEmail()) ) && 
											(obj.getFrom().equals(((Ticket) x).getFrom())))
									{
										return true;
									}
								}
								return false;
};

private void bookCarTicket(Ticket x) {
	//assume Car is booked by making some entries in db
LocalDate sDate=x.getStartDate();
LocalDate eDate=x.getEndDate();
try {
	
	if(!eDate.isAfter(sDate))
	{
		throw new UserDefineException("Start Date should be lesser than end date.");
	}	

	if(check.test(busTicketList, x))
	{
		throw new UserDefineException("Your Ticket is already booked for this date");
	}
	
	busTicketList.add(x);
	
	
	
}catch(Exception ex)
{
	System.out.println(ex);
	
}

}

private void bookBusTicket(Ticket x) {
	//assume Bus is booked by making some entries in db
	LocalDate sDate=x.getStartDate();
	LocalDate eDate=x.getEndDate();
	try
	{
	if(!eDate.isAfter(sDate))
	{
		throw new UserDefineException("Start Date should be lesser than end date.");
	}	

	if(check.test(busTicketList, x))
	{
		throw new UserDefineException("Your Ticket is already booked for this date");
	}
	
	carTicketList.add(x);
	
	}catch(Exception ex)
	{
		System.out.println(ex);
		
	}
}


private void sendTicketBookedMail(Ticket x) {
	//Assume email is sent to passenger that his/her ticket is booked
	
	 // email ID of Recipient. 
    String recipient =  x.getPassenger().getEmail(); 

    // email ID of  Sender. 
    String sender = "mailmeatravikant@gmail.com";

    // using host as localhost 
    String host = "localhost"; 

    // Getting system properties 
    Properties properties = System.getProperties(); 

    // Setting up mail server 
    properties.setProperty("mail.smtp.host", host); 

    // creating session object to get properties 
    Session session = Session.getDefaultInstance(properties); 

    try 
    { 
       // MimeMessage object. 
       MimeMessage message = new MimeMessage(session); 

       // Set From Field: adding senders email to from field. 
       message.setFrom(new InternetAddress(sender)); 

       // Set To Field: adding recipient's email to from field. 
       message.addRecipient(Message.RecipientType.TO, new InternetAddress(recipient)); 

       // Set Subject: subject of the email 
       message.setSubject("Ticket Book for date "+ x.getStartDate() +" To date "+x.getEndDate()); 

       // set body of the email.
       String successMessage=" Congratulation "+x.getPassenger().getName()+" \n "+" Your Ticket has been successfully booked from "
    		   					+ x.getStartDate() +" To date "+x.getEndDate();
       message.setText(successMessage); 

       // Send email. 
       Transport.send(message); 
       System.out.println("Mail successfully sent"); 
    } 
    catch (MessagingException mex)  
    { 
       mex.printStackTrace(); 
    } 
 } 
	
	

//Ensure all input data is present
void validateAllFieldsPresent(Ticket ticket) {
	Objects.requireNonNull(ticket,"Ticket details must not be null");
	Objects.requireNonNull(ticket.getStartDate(),"Start date must not be null");
	Objects.requireNonNull(ticket.getEndDate()," End date mst not be null");
	
	Objects.requireNonNull(ticket.getFrom(),"From Location must not be null");
	Objects.requireNonNull(ticket.getDestination(),"Destination details must not be null");
	Objects.requireNonNull(ticket.getPassenger()," Passenger details must not be null");
	
}
}


